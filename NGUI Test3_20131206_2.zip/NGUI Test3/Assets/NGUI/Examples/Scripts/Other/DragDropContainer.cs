//----------------------------------------------
//            NGUI: Next-Gen UI kit
// Copyright � 2011-2012 Tasharen Entertainment
//----------------------------------------------

using UnityEngine;

[AddComponentMenu("NGUI/Examples/Drag and Drop Container")]
public class DragDropContainer : MonoBehaviour
{
	// No code here. Attaching this script simply identifies it as a container for the DragDropObject script.
}